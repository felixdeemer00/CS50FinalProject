-- HOW TO RUN / INSTALL --

Room Escape is a ASCII art-based video game, inspired by games like NetHack and Rogue that I have enjoyed throughout my 
life. The game was built in Python but was exported using PyInstaller, so it should run by simply executing the file
named 'RoomEscape.exe' in the csProjectV2 folder this README document is in. It can be run on a mac and should work
fine on windows, as PyInstaller ensures that neither Python nor PyGame need be installed on the user's computer.

To run the program from the original .py file, both Python3.10 and the newest version of PyGame should be installed
on the user's computer. With Python installed, PyGame can be quickly installed by running the lines of code
specified on the PyGame website (https://www.pygame.org/wiki/GettingStarted), and then the program itself can be
executed by running 'python3.10 RoomEscape.py' when the user is in the final project directory.

-- HOW TO PLAY --

Room Escape uses text-based ASCII graphics, with keyboard symbols used to represent items in the game. The 'X' symbol,
for example, represents the player character, with '#' and '.' representing wall and floor tiles respectively. The other
symbols used in the game, such as water, pressure plates, and traps, are introduced in the game by hints and often have 
different colors to set them apart.

You control the player character by using the arrow keys to move. There are no other controls in the game, as simple
movement still allows the player to complete the puzzles in the game successfully.

Link to video description: https://youtu.be/qqD_37aqaGM