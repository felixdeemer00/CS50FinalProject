import pygame, sys, random
from pygame.locals import *

#
# Create tile class
#

class tile:
  
  def __init__(self, num, form, symbol, obj, attr, room, player, visible, color):
      
    # self.num is a tile coordinate, used to identify individual tiles
    self.num = num
    
    # self.form is the type of tile, a water, floor, wall tile etc. The form stays constant throughout the game
    self.form = form

    # self.symbol is the symbol displayed for the tile, based off the type/object values
    self.symbol = symbol

    # self.obj represents the objects present in the tile, either enemies, blocks, or other objects
    self.obj = obj

    # self.attr represents additional attributes of the tile, used to save pressure plates being activated
    self.attr = attr

    # self.room stores the room number, used to calculate room visibility
    self.room = room

    # self.visible stores whether or not this tile can be seen by the player
    self.visible = visible

    # self.color stores the color that should be displayed in the game
    self.color = color

#
# Basic Game Setup
#

importBoard = ['######## ######## ######## ',
               '#X.....###......# #.=....# ',
               '#......0.......0# #.0....# ',
               '#......###......# #=....=# ',
               '#......# #~~~~~~###....0.# ', 
               '#......# #~~~~~~.........# ',
               '#......# #~~~~~~###..0..=# ',
               '######## ######## ####&### ',
               '                     #.#   ',
               '######## ######## ####.### ',
               '#......###......# #......# ',
               '#.,.............# #.,....# ',
               '#......###......###......# ',
               '#......# #........,..,...# ',
               '#.,.,..# #..D...###....,.# ',
               '#,.....# #......# #.,....# ',
               '##.##### ######## ######## ',
               ' #.#                       ',
               '##.##### ######## #########',
               '#......# #......###.......#',
               '#..00..# #.,..,.....=...=.#',
               '#,,,,,,# #,..,,,###.,...,.#',
               '#......# #~~~~~~# #.0.=.0.#',
               '#,,,,,,###...0..# #.0...0.#',
               '#...............# #.=...=.#',
               '################# #.......#',
               '                  ####&####',
               '                     #*#   ']

playerCoord = [1, 1]
gameStatus = 'inProgress'

# This is the starting hint displayed at the top of the screen, and changes with each room.

hint = 'To open a way out, try moving the block.. (Use arrow keys to move)'

#
# Initialize and create game board
#

def initBoard(height, width):
  
    # This function sets up the initial state of the board, with every square being a default floor tile. Floor
    # types are loaded in later.
    
    gameBoard = []
    
    for i in range(height):
      row = []
      
      for j in range(width):
        row.append(tile([], 'floor', '.', [], [], 0, False, False, (250,250,250)))
        
      gameBoard.append(row)
      
    return gameBoard

def createBoard(gameBoard, importBoard, playerCoord):
  
    # This function fills in all the tiles with the pre-made game map, stored in the importBoard variable.
    # This contains all the information necessary for creating the game map.
    
    for i in range(len(gameBoard)):
      
        for j in range(len(gameBoard[i])):
          
            newTile = importBoard[i][j]
            gameBoard[i][j].num = [i, j]

            if i >= 0 and i <= 7 and j >= 0 and j <= 8:
                gameBoard[i][j].visible = True
            
            if newTile == '#':
                gameBoard[i][j].form = 'wall'
                gameBoard[i][j].symbol = '#'
                gameBoard[i][j].color = (192, 192, 192)

            elif newTile == ' ':
                gameBoard[i][j].form = 'none'
                gameBoard[i][j].symbol = ' '

            elif newTile == 'X':
                playerCoord = [i, j]

            elif newTile == '0':
                gameBoard[i][j].obj.append('block')
                gameBoard[i][j].symbol = '0'

            elif newTile == '=':
                gameBoard[i][j].form = 'plate'
                gameBoard[i][j].symbol = '='

            elif newTile == '`':
                gameBoard[i][j].attr.append('reveal')

            elif newTile == '~':
                gameBoard[i][j].form = 'water'
                gameBoard[i][j].symbol = '~'
                gameBoard[i][j].color = (51,153,255)

            elif newTile == '&':
                gameBoard[i][j].obj.append('lockDoor')
                gameBoard[i][j].symbol = '&'
                gameBoard[i][j].color = (192, 192, 192)

            elif newTile == ',':
                gameBoard[i][j].form = 'trap'
                gameBoard[i][j].symbol = ','
                gameBoard[i][j].color = (255,229,204)

            elif newTile == 'D':
                gameBoard[i][j].form = 'discoMan'
                gameBoard[i][j].symbol = 'D'
                gameBoard[i][j].color = (255,178,102)

            elif newTile == '*':
                gameBoard[i][j].form = 'goal'
                gameBoard[i][j].symbol = '*'
                gameBoard[i][j].color = (204,204,0)

def dispBoard():

    global gameBoard, playerCoord, hint

     # Creates a background object to be displayed onscreen
     
    background.fill((0, 0, 0))

    font = pygame.font.Font(None, 20)
    text = font.render(hint, 1, (250,250,250))
    textpos = [30,30]
    background.blit(text, textpos)

    # Gets the symbols from the game board to create the text objects to be displayed
    
    for i in range(len(gameBoard)):
        for j in range(len(gameBoard[i])):

            # Setting colors for objects
            
            if playerCoord[0] == i and playerCoord[1] == j:
                sym = 'X'
                color = (255,178,102)
            elif gameBoard[i][j].visible == False:
                color = (0,0,0)
            elif gameBoard[i][j].symbol == '~':
                sym = '~'
                color = random.choice([(51,153,255),(153,204,255),(51,153,255),(51,153,255)])
            else:
                sym = gameBoard[i][j].symbol
                color = gameBoard[i][j].color

            # This section of code creates the text objects to be displayed onscreen to represent the game board
            
            font = pygame.font.Font(None, 30)
            text = font.render(sym, 1, color)
            textpos = [j*15 + 40,i*20 + 70]
            background.blit(text, textpos)
            
    screen.blit(background, (0, 0))
    pygame.display.flip()

gameBoard = initBoard(28,27)
createBoard(gameBoard, importBoard, playerCoord)
    
#
# Initialise screen
#

pygame.init()
size = (475,650)
screen = pygame.display.set_mode(size)
pygame.display.set_caption('Room Escape')
background = pygame.Surface(screen.get_size())
background = background.convert()

#
# Iterate board
#

# Function to change room visibility

def roomReveal(room,rx,ry,a,b,c,d):
    global playerCoord, gameBoard, hint

    # This function controls what the user is able to see at any given moment, as the user should not be able to
    # see the whole game board at the beginning. When the user crosses from one room to another, this function
    # alters the .visible attribute of the tile classes in the new room to make them show up on the display.
    # It also updates the hint displayed at the top of the screen.

    hints = ['The blocks can be used to create a bridge..',
             'The blocks can weigh down the pressure plates to unlock the door..',
             'Watch out for the floor traps..',
             'Wise old man Don speaks: "Watch your step in the next rooms.."',
             'This one doesn\'t seem too bad..',
             'You\'ll need to use the blocks to fill the traps..',
             'Look carefully at the other side of the river..',
             'Think several moves ahead here..']

    if playerCoord[0] == rx and playerCoord[1] == ry:
        for i in range(a,b):
            for j in range(c,d):
                gameBoard[i][j].visible = True

        hint = hints[room]

def iterateBoard():
    global playerCoord, gameBoard, gameStatus

    # This section gets input from the user to carry out player movement
    
    if event.key == pygame.K_UP:
        dest = [playerCoord[0] - 1, playerCoord[1]]
        over = [playerCoord[0] - 2, playerCoord[1]]
                
    elif event.key == pygame.K_DOWN:
        dest = [playerCoord[0] + 1, playerCoord[1]]
        over = [playerCoord[0] + 2, playerCoord[1]]
                
    elif event.key == pygame.K_LEFT:
        dest = [playerCoord[0], playerCoord[1] - 1]
        over = [playerCoord[0], playerCoord[1] - 2]
                
    elif event.key == pygame.K_RIGHT:
        dest = [playerCoord[0], playerCoord[1] + 1]
        over = [playerCoord[0], playerCoord[1] + 2]

    # This section of code determines block movement, moving blocks if a player moves into them and removing
    # traps or water in the block's way.

    if 'block' in gameBoard[dest[0]][dest[1]].obj and not gameBoard[over[0]][over[1]].obj and gameBoard[over[0]][over[1]].form != 'wall':
        gameBoard[dest[0]][dest[1]].obj = []
        gameBoard[dest[0]][dest[1]].symbol = '.'
                
        if gameBoard[over[0]][over[1]].form == 'water' or gameBoard[over[0]][over[1]].form == 'trap':
            gameBoard[over[0]][over[1]].color = (250,250,250)
            gameBoard[over[0]][over[1]].form = 'floor'
            gameBoard[over[0]][over[1]].symbol = '.'
        else:
            gameBoard[over[0]][over[1]].obj.append('block')
            gameBoard[over[0]][over[1]].symbol = '0'

    if gameBoard[dest[0]][dest[1]].form in ['floor', 'plate', 'goal', 'trap'] and not gameBoard[dest[0]][dest[1]].obj:
        playerCoord = dest

    # Changing room visibility

    roomReveal(0,2,7,0,8,9,18)
    roomReveal(1,5,17,0,9,18,26)
    roomReveal(2,8,22,9,17,17,26)
    roomReveal(3,13,17,9,17,8,17)
    roomReveal(4,11,8,9,18,0,8)
    roomReveal(5,17,2,18,26,0,9)
    roomReveal(6,24,8,18,26,9,18)
    roomReveal(7,20,17,18,28,18,27)

    # Iterating through every block, allowing other changes to happen in the game world

    pressurePlateActive = 0

    for i in range(len(gameBoard)):
        for j in range(len(gameBoard[i])):

            # Pressure plate activation   

            if 'block' in gameBoard[i][j].obj and gameBoard[i][j].form == 'plate':
                pressurePlateActive += 1
            elif gameBoard[i][j].form == 'plate' and playerCoord[0] == i and playerCoord[1] == j:
                pressurePlateActive += 1

            # Check activation of pressure plates and unlocking door

            if pressurePlateActive == 4:
                gameBoard[7][22].symbol = '.'
                gameBoard[7][22].obj = []
                gameBoard[7][22].form = 'floor'

            # Check activation of final pressure plates and unlocking door
                
            if pressurePlateActive == 8:
                gameBoard[26][22].symbol = '.'
                gameBoard[26][22].obj = []
                gameBoard[26][22].form = 'floor'

     # Check collision between player and trap, resulting in a game loss

    if gameBoard[playerCoord[0]][playerCoord[1]].form == 'trap':
        gameStatus = 'lost'

    # Checks collision between player and the goal, resulting in game victory

    elif gameBoard[playerCoord[0]][playerCoord[1]].form == 'goal':
        gameStatus = 'won'

while gameStatus == 'inProgress':
    for event in pygame.event.get():
        
        if event.type == QUIT:
            sys.exit()

        elif event.type == pygame.KEYDOWN:
            iterateBoard()
            
    dispBoard()
   
if gameStatus == 'lost':
    while 1:
        for event in pygame.event.get():
            if event.type == QUIT:
                sys.exit()

        font = pygame.font.Font(None, 60)
        text = font.render('GAME OVER', 1, (255,178,102))
        textpos = [100,200]
        background.blit(text, textpos)
        
        font2 = pygame.font.Font(None, 40)
        text2 = font2.render('You stepped in a trap', 1, (255,178,102))
        textpos2 = [85,260]
        
        background.blit(text2, textpos2)
        screen.blit(background, (0, 0))
        pygame.display.flip()

if gameStatus == 'won':
    while 1:
        for event in pygame.event.get():
            if event.type == QUIT:
                sys.exit()

        font = pygame.font.Font(None, 60)
        text = font.render('VICTORY', 1, (204,204,0))
        textpos = [150,220]
        background.blit(text, textpos)
        screen.blit(background, (0, 0))
        pygame.display.flip()

