This game was created using the PyGame module, due to my higher level of comfort in programming in Python compared to other
languages. It allows one to easily render text and other graphics, and made creating a ASCII-based game very intuitive.

The game revolves around creating a map of the board using a series of nested lists, with strings of characters used to
represent the actual tiles in the game. The game begins with a function that initializes the board, creating a set of
blank tiles that are then filled in by importing the game map. This allows changes to be made to the game map very easily,
by simply changing the character strings in the .py file - the program automatically interprets the characters and 
assigns a tile characteristics based off of it. The tiles themselves are objects, with different object variables 
representing everything that needs to be known by the computer about a given tile.

The PyGame graphics module then displays the game board by simply printing out the character map of the board, updating
whenever the user hits one of the input keys. Whenever the user hits a button, it activates the IterateBoard function,
which checks whether the player is able to execute the desired move, as well as moving any blocks and activating any
pressure plates in the player's way.

I chose to create an ASCII-based game as I was inspired by roguelikes I have enjoyed in the past, and because I found that
the PyGame library lended itself very well to creating those games, allowing me to use color and display text in addition
to displaying the ASCII graphics.